- 👋 Olá, meu nome é Ana Mel
- 🌱sou estudante e aprendo programação
- 💞️ moro no interior de SP, Brasil
- 📫 você pode me mandar um email em anamelbossolansilva@gmail.com

<!---
anaamel/anaamel is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
